TriDiseaseRank-X: FINAL MASTER SCRIPT WITH ML TOP-GENE EXTERNAL VALIDATION
Version: 2026-11-20

MAIN FILE
  TDR_FINAL_WITH_ML_INDEPENDENT_VALIDATION.R

The file follows the exact original TDR_FINAL.R discovery workflow, in the
same order: DEG -> WGCNA -> shared candidates -> TD-CCHI GNN -> 113-model ML
-> pathway -> five-layer final ranking. New independent ML validation is
INSERTED IMMEDIATELY AFTER the 113-model ML section. Original scientific
statements, settings and algorithms are not rewritten. New optional GNN
external evidence and TIFF conversion sections are appended after fusion.

INDEPENDENT ML VALIDATION
  The original 113 ML module exports gene_ML_scores.csv for each disease.
  The new section chooses the top 3 genes per disease, sorted by
  S_ML_Disease then ML_TopModelSupportCount, then gene name.
  The selected genes are DYNAMIC, not hardcoded MXRA5/COL7A1/FREM1.
  It fits a NEW prespecified ridge logistic classifier (alpha=0) using
  only the corresponding discovery cohort. Lambda=1se is chosen using
  stratified discovery-only CV. The decision threshold is fixed at 0.50.
  Each sample is normalized as log2(raw counts per million + 1), with
  library size computed from ALL genes in that sample. The frozen model,
  genes, lambda and threshold are saved before external data are opened.
  External labels never determine feature selection, model tuning,
  preprocessing parameters or the decision threshold.
  This is validation of a NEW classifier built on 113ML-RANKED genes,
  NOT validation of all 113 original classifiers or their winner.

DATASETS
  D1: discovery GSE172381 -> external GSE203507
      Primary comparison: villous EOPE (8) vs iPTB (5), verified phenotype
      manifest. Sensitivity: villous composite (20 vs 10) and decidual
      composite (17 vs 10), using exactly the same frozen model.
      The composite includes FGR-only cases and must not be described as
      pure preeclampsia diagnosis.
  D2: discovery GSE120852 -> external GSE208592 (PAH lung 15 vs 18).
      This is cross-phenotype/tissue transfer, NOT systemic HTN validation.
  D3: discovery GSE161349 -> external GSE100243 (16 vs 7).
      Discovery contrasts colorectal cancer sphere mutation background;
      external contrasts tumor/metastatic vs normal. NOT a clinical
      tumor-vs-healthy diagnostic validation of the same target.
  Potential patient-level nonindependence in some external cohorts cannot
  be excluded without subject identifiers. CIs assume sample independence.

METRICS (external, NO retraining)
  ROC AUC + 95% CI (DeLong, stratified bootstrap fallback)
  Sensitivity + exact 95% CI; specificity + exact 95% CI
  Balanced accuracy + stratified bootstrap 95% CI
  Confusion matrix (TP, FP, TN, FN); accuracy; Brier score
  Fixed-bin descriptive calibration figures. Formal intercept/slope are
  omitted for small cohorts, to avoid unreliable estimates.
  Gene coverage, external expression shift, per-sample predictions,
  frozen RDS models and input hashes are exported.

TIFF FIGURES
  Every new ML external plot is directly saved as 300-dpi LZW TIFF.
  Original discovery/GNN/113ML/pathway PNG plots are additionally converted
  to LZW TIFF, retaining their native pixel dimensions. PDF/PNG originals
  remain available. TIFF_EXPORT_STATUS.csv identifies any conversion issue.
  Install either the R package 'png' or 'magick' to convert original PNGs.
  The conversion does not increase actual image resolution.

HOW TO RUN (Windows VS Code / R terminal)
  1. Extract the READY ZIP. Keep all CSVs and R files in ONE folder.
  2. Set the R working directory to the extracted folder:
     setwd("D:/TriDiseaseRankX_TOPGENE_VALIDATION")
  3. Install required packages from the original discovery modules,
     including torch and its runtime, plus glmnet, pROC, and png.
     install.packages(c("glmnet", "pROC", "png"))
  4. source("TDR_FINAL_WITH_ML_INDEPENDENT_VALIDATION.R")
     OR Rscript TDR_FINAL_WITH_ML_INDEPENDENT_VALIDATION.R

OUTPUT LOCATIONS
  TriDiseaseRank_results/Phase1_DEG_D1..D3
  TriDiseaseRank_results/Phase2_WGCNA_D1..D3
  TriDiseaseRank_results/Phase4_TD_CCHI_GNN
  TriDiseaseRank_results/Phase5_113ML/D1..D3
  TriDiseaseRank_results/Phase5B_113ML_TopGenes_Independent_Validation/
      D1/D2/D3/{PRIMARY, SENSITIVITY_*}/external_metrics.csv
      D1/D2/D3/LOCKED_ML_topgenes_ridge_model.rds
      ALL_DISEASE_EXTERNAL_METRICS.csv
      ML_EXTERNAL_VALIDATION_STATUS.csv
  TriDiseaseRank_results/Phase6_Pathway
  TriDiseaseRank_results/Phase7_Prioritized_Biomarkers
  TriDiseaseRank_results/Phase8_GNN_External_Evidence (if enabled)
  TIFF_EXPORT_STATUS.csv

CONFIGURATION IN MAIN SCRIPT
  RUN_ML_EXTERNAL <- TRUE
  ML_EXTERNAL_TOP_N <- 3L
  RUN_GNN_EXTERNAL <- TRUE
  RUN_TIFF_EXPORT <- TRUE

IMPORTANT EXECUTION NOTE
  This package was statically audited and the 12 CSV inputs were checked,
  but the complete R pipeline was NOT executed in the packaging environment
  because Rscript and the R torch runtime were unavailable. Model results,
  AUCs and actual TIFF output are generated only when you run it in R.
  Confirm per-disease status CSVs and TIFF_EXPORT_STATUS.csv before use.
  The original 113 ML checkpoint mechanism can reuse old results; use a
  fresh folder when datasets or candidate-selection settings change.

SOURCE INTEGRITY
  TDR_FINAL.R, TD_CCHI_GNN_R.R, TriDiseaseRankX_113ML_Internal.R,
  TriDiseaseRankX_Pathway.R and supplied TDR_ML.R / TDR_Pathway.R are
  unmodified copies. See ORIGINAL_SCRIPTS_UNCHANGED_SHA256.csv.
