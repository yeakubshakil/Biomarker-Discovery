###############################################################################
# TDR_FINAL + INDEPENDENT VALIDATION OF 113-ML TOP-RANKED GENES
# This file contains the ORIGINAL TDR_FINAL discovery code, in the same order,
# with only ADDITIONAL settings/validation/TIFF/GNN evidence sections inserted.
# Run from this script's folder: source("TDR_FINAL_WITH_ML_INDEPENDENT_VALIDATION.R")
# Scientific note: external ML model is a NEW ridge refit on the ML-ranked
# genes; it is not external validation of every original 113 classifier.
###############################################################################

############################################################
# TriDiseaseRank-X — FINAL CONCISE DISCOVERY PIPELINE
# Stops at prioritized biomarkers.
#
# Workflow:
#   raw counts + metadata
#   -> limma-voom DEG
#   -> WGCNA
#   -> shared DEG + WGCNA integration
#   -> TD-CCHI custom GNN (pure R/torch)
#   -> 113-model ML
#   -> pathway convergence
#   -> five-layer TriDiseaseRank-X ranking
#
# Deferred: ANN, external validation, regulatory interpretation.
############################################################

# ==========================================================
# 0. PROJECT PATHS + SETTINGS
# ==========================================================

get_script_dir <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  f <- grep("^--file=", args, value = TRUE)
  if (length(f)) return(dirname(normalizePath(sub("^--file=", "", f[1]), mustWork = FALSE)))
  getwd()
}

SCRIPT_DIR <- get_script_dir()
DATA_DIR <- Sys.getenv("TDRX_DATA_DIR", unset = SCRIPT_DIR)
OUT_DIR <- file.path(SCRIPT_DIR, "TriDiseaseRank_results")
dir.create(OUT_DIR, recursive = TRUE, showWarnings = FALSE)

sample_col <- "Samples"
condition_col <- "Condition"
control_label <- "Control"
case_label <- "Case"
candidate_covariates <- c("batch", "sex", "age")

# DEG
DEG_FDR <- 0.05
DEG_LOG2FC <- 1
FILTER_MIN_COUNT <- 10
USE_SVA <- TRUE

# WGCNA
WGCNA_TOP_VAR <- 5000L
WGCNA_NETWORK_TYPE <- "signed"
WGCNA_COR <- "pearson"       # change to "bicor" only if prespecified
WGCNA_MIN_MODULE <- 30L
WGCNA_DEEP_SPLIT <- 2L
WGCNA_MERGE_HEIGHT <- 0.25
WGCNA_MODULE_P <- 0.05
WGCNA_SUPPORT_MIN <- 3L       # strict support in all 3 datasets

# TD-CCHI
RUN_GNN <- TRUE
GNN_BOOTSTRAPS <- 100L
GNN_TOP_FRACTION <- 0.10
GNN_TOP_N_FOR_ML <- 20L
GNN_WARMUP_EPOCHS <- 250L
GNN_CLUSTER_EPOCHS <- 200L
GNN_PATIENCE <- 60L

# 113-ML
RUN_ML <- TRUE
ML_OUTER_FOLDS <- 5L
ML_INNER_FOLDS <- 4L
ML_TUNING_LENGTH <- 3L
ML_TOP_MODELS <- 20L
ML_WORKERS <- min(4L, max(1L, parallel::detectCores(logical = TRUE) - 1L))


# ==========================================================
# ADD-ON SETTINGS: 113-ML TOP-GENE INDEPENDENT VALIDATION
# ==========================================================
RUN_ML_EXTERNAL <- TRUE
ML_EXTERNAL_TOP_N <- 3L          # top 3 per disease by S_ML_Disease
RUN_GNN_EXTERNAL <- TRUE        # independent frozen GNN evidence add-on
RUN_TIFF_EXPORT <- TRUE         # original PNG -> LZW TIFF; new plots direct TIFF
if (isTRUE(RUN_TIFF_EXPORT) &&
    !requireNamespace("png", quietly = TRUE) &&
    !requireNamespace("magick", quietly = TRUE)) {
  stop("TIFF export needs an image reader: install.packages('png') or install.packages('magick')")
}
# Original discovery settings above and below remain unchanged.


# Pathway
RUN_PATHWAY <- TRUE

# Final fusion
FINAL_TOP_N <- 10L
PRIMARY_WEIGHTS <- c(DEG = 0.20, WGCNA = 0.20, GNN = 0.20, ML = 0.20, Pathway = 0.20)

analysis_list <- list(
  D1 = list(gse_id = "GSE172381", counts = "GSE172381_counts_data.csv", metadata = "GSE172381_metadata.csv"),
  D2 = list(gse_id = "GSE120852", counts = "GSE120852_counts_data.csv", metadata = "GSE120852_metadata.csv"),
  D3 = list(gse_id = "GSE161349", counts = "GSE161349_counts_data.csv", metadata = "GSE161349_metadata.csv")
)

# ==========================================================
# 1. PACKAGES + INPUT PREFLIGHT
# ==========================================================

required <- c("edgeR", "limma", "sva", "WGCNA", "data.table", "dplyr", "tidyr",
              "ggplot2", "matrixStats", "openxlsx", "torch")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing)) stop("Install missing R packages: ", paste(missing, collapse = ", "))

suppressPackageStartupMessages({
  library(edgeR); library(limma); library(sva); library(WGCNA)
  library(data.table); library(dplyr); library(tidyr); library(ggplot2)
  library(matrixStats); library(openxlsx); library(torch)
})

options(stringsAsFactors = FALSE, scipen = 999)
set.seed(20260908)
try(WGCNA::allowWGCNAThreads(), silent = TRUE)

resolve_input <- function(name) {
  candidates <- unique(c(file.path(DATA_DIR, name), file.path(SCRIPT_DIR, name), file.path(getwd(), name), name))
  hit <- candidates[file.exists(candidates)]
  if (!length(hit)) stop("Input file not found: ", name, "\nChecked: ", paste(candidates, collapse = " | "))
  normalizePath(hit[1], mustWork = TRUE)
}

for (d in names(analysis_list)) {
  analysis_list[[d]]$counts_file <- resolve_input(analysis_list[[d]]$counts)
  analysis_list[[d]]$metadata_file <- resolve_input(analysis_list[[d]]$metadata)

  md <- data.table::fread(analysis_list[[d]]$metadata_file, data.table = FALSE)
  ct <- data.table::fread(analysis_list[[d]]$counts_file, nrows = 2L, data.table = FALSE, check.names = FALSE)

  if (!all(c(sample_col, condition_col) %in% names(md))) {
    stop(d, ": metadata must contain '", sample_col, "' and '", condition_col,
         "'. Found: ", paste(names(md), collapse = ", "))
  }
  if (ncol(ct) < 4L) stop(d, ": count file needs gene ID, gene_symbol and sample columns.")

  count_samples <- names(ct)[-(1:2)]
  meta_samples <- trimws(as.character(md[[sample_col]]))
  missing_samples <- setdiff(meta_samples, count_samples)
  if (length(missing_samples)) stop(d, ": metadata/count sample mismatch: ", paste(head(missing_samples, 10), collapse = ", "))

  bad_labels <- setdiff(unique(trimws(as.character(md[[condition_col]]))), c(control_label, case_label))
  if (length(bad_labels)) stop(d, ": unexpected Condition label(s): ", paste(bad_labels, collapse = ", "))

  cat(sprintf("[OK] %s (%s): %d metadata samples\n", d, analysis_list[[d]]$gse_id, nrow(md)))
}

# ==========================================================
# 2. HELPERS
# ==========================================================

clean_gene <- function(x) {
  x <- toupper(trimws(as.character(x)))
  x[x %in% c("", "NA", "N/A", "---", "--", ".", "NULL")] <- NA_character_
  x
}

minmax01 <- function(x) {
  x <- as.numeric(x); x[!is.finite(x)] <- NA_real_
  r <- range(x, na.rm = TRUE)
  if (!all(is.finite(r)) || r[1] == r[2]) return(rep(0, length(x)))
  y <- (x - r[1]) / (r[2] - r[1]); y[!is.finite(y)] <- 0
  pmin(pmax(y, 0), 1)
}

clamp01 <- function(x) pmin(pmax(as.numeric(x), 0), 1)

usable_covariates <- function(md) {
  x <- intersect(candidate_covariates, names(md))
  x[vapply(x, function(v) length(unique(na.omit(md[[v]]))) > 1L, logical(1))]
}

prepare_meta <- function(md) {
  names(md) <- trimws(names(md))
  md[[sample_col]] <- trimws(as.character(md[[sample_col]]))
  md[[condition_col]] <- trimws(as.character(md[[condition_col]]))
  md <- md[md[[condition_col]] %in% c(control_label, case_label), , drop = FALSE]
  md[[condition_col]] <- factor(md[[condition_col]], levels = c(control_label, case_label))

  covs <- usable_covariates(md)
  for (v in covs) {
    if (is.numeric(md[[v]]) || is.integer(md[[v]])) {
      if (anyNA(md[[v]])) md[[v]][is.na(md[[v]])] <- median(md[[v]], na.rm = TRUE)
    } else {
      z <- as.character(md[[v]]); z[is.na(z) | !nzchar(trimws(z))] <- "Unknown"; md[[v]] <- factor(z)
    }
  }
  list(metadata = md, covariates = covs)
}

save_pca <- function(expr, md, path, title) {
  keep <- matrixStats::rowVars(as.matrix(expr), na.rm = TRUE) > 0
  if (sum(keep) < 2L || ncol(expr) < 3L) return(invisible(NULL))
  pca <- prcomp(t(expr[keep, , drop = FALSE]), scale. = TRUE)
  ve <- 100 * pca$sdev^2 / sum(pca$sdev^2)
  df <- data.frame(PC1 = pca$x[,1], PC2 = pca$x[,2], Condition = md[[condition_col]])
  p <- ggplot(df, aes(PC1, PC2, color = Condition)) + geom_point(size = 3) + theme_bw() +
    labs(title = title, x = sprintf("PC1 (%.1f%%)", ve[1]), y = sprintf("PC2 (%.1f%%)", ve[2]))
  ggsave(path, p, width = 6.5, height = 5, dpi = 300)
}

# ==========================================================
# 3. DEG: RAW COUNTS -> TMM -> VOOM -> LIMMA (+ OPTIONAL SVA)
# ==========================================================

run_deg <- function(d, cfg) {
  cat("\n=== DEG: ", d, " (", cfg$gse_id, ") ===\n", sep = "")
  out <- file.path(OUT_DIR, paste0("Phase1_DEG_", d)); dir.create(out, recursive = TRUE, showWarnings = FALSE)

  raw <- data.table::fread(cfg$counts_file, data.table = FALSE, check.names = FALSE)
  md0 <- data.table::fread(cfg$metadata_file, data.table = FALSE, check.names = FALSE)
  mi <- prepare_meta(md0); md <- mi$metadata; covs <- mi$covariates

  gene_id <- as.character(raw[[1]]); gene_symbol <- clean_gene(raw[[2]])
  counts <- as.matrix(raw[, -(1:2), drop = FALSE]); suppressWarnings(storage.mode(counts) <- "double")
  rownames(counts) <- gene_id

  common <- md[[sample_col]][md[[sample_col]] %in% colnames(counts)]
  if (length(common) != nrow(md)) stop(d, ": not all metadata samples are present in counts.")
  counts <- counts[, common, drop = FALSE]; md <- md[match(common, md[[sample_col]]), , drop = FALSE]

  if (anyNA(counts) || any(!is.finite(counts))) stop(d, ": non-finite count values found.")
  if (any(counts < 0)) stop(d, ": negative values found; this is not raw count data.")
  if (mean(counts %% 1 == 0) < 0.95) warning(d, ": >5% non-integer values; verify raw-count input.")

  # unique gene IDs: retain highest-count row
  keep <- !is.na(rownames(counts)) & nzchar(rownames(counts)) & rowSums(counts) > 0
  counts <- counts[keep, , drop = FALSE]; gene_symbol <- gene_symbol[keep]; gene_id <- gene_id[keep]
  if (anyDuplicated(rownames(counts))) {
    ord <- order(rownames(counts), -rowSums(counts)); counts <- counts[ord, , drop = FALSE]
    gene_symbol <- gene_symbol[ord]; gene_id <- gene_id[ord]
    u <- !duplicated(rownames(counts)); counts <- counts[u, , drop = FALSE]; gene_symbol <- gene_symbol[u]; gene_id <- gene_id[u]
  }
  annot <- data.frame(gene_id = rownames(counts), gene_symbol = gene_symbol, stringsAsFactors = FALSE)

  dge <- edgeR::DGEList(counts)
  design_formula <- reformulate(c(condition_col, covs))
  design <- model.matrix(design_formula, md); colnames(design) <- make.names(colnames(design))

  keep <- edgeR::filterByExpr(dge, group = md[[condition_col]], min.count = FILTER_MIN_COUNT)
  dge <- edgeR::calcNormFactors(dge[keep, , keep.lib.sizes = FALSE], method = "TMM")

  v0 <- limma::voom(dge, design, plot = FALSE)
  final_design <- design; n_sv <- 0L

  if (USE_SVA && ncol(v0$E) - qr(design)$rank >= 3L) {
    null_formula <- if (length(covs)) reformulate(covs) else ~1
    mod0 <- model.matrix(null_formula, md)
    n_sv <- tryCatch(as.integer(sva::num.sv(v0$E, design, method = "be")), error = function(e) 0L)
    if (is.finite(n_sv) && n_sv > 0L) {
      sv <- tryCatch(sva::sva(v0$E, mod = design, mod0 = mod0, n.sv = n_sv)$sv, error = function(e) NULL)
      if (!is.null(sv)) {
        candidate_design <- cbind(design, sv); colnames(candidate_design) <- c(colnames(design), paste0("SV", seq_len(ncol(sv))))
        if (qr(candidate_design)$rank == ncol(candidate_design)) final_design <- candidate_design else n_sv <- 0L
      } else n_sv <- 0L
    }
  }

  v <- limma::voom(dge, final_design, plot = FALSE)
  fit <- limma::eBayes(limma::lmFit(v, final_design), robust = TRUE)

  coef_target <- paste0(make.names(condition_col), make.names(case_label))
  hit <- which(colnames(final_design) == coef_target)
  if (length(hit) != 1L) hit <- grep(paste0(make.names(condition_col), ".*", make.names(case_label)), colnames(final_design))
  if (length(hit) != 1L) stop(d, ": cannot identify Case-vs-Control coefficient. Design: ", paste(colnames(final_design), collapse = ", "))

  tab <- limma::topTable(fit, coef = hit, number = Inf, adjust.method = "BH", sort.by = "P")
  tab$gene_id <- rownames(tab)
  tab$gene_symbol <- annot$gene_symbol[match(tab$gene_id, annot$gene_id)]
  tab$gene_symbol[is.na(tab$gene_symbol)] <- tab$gene_id[is.na(tab$gene_symbol)]
  tab$gene_symbol <- clean_gene(tab$gene_symbol)
  tab$padj <- tab$adj.P.Val
  tab$DEG_raw <- -log10(pmax(tab$padj, 1e-300)) * abs(tab$logFC)
  tab$S_DEG <- minmax01(tab$DEG_raw)
  tab <- tab[!is.na(tab$gene_symbol), , drop = FALSE]
  tab <- tab[order(tab$padj, -abs(tab$logFC)), ]; tab <- tab[!duplicated(tab$gene_symbol), ]
  sig <- tab[tab$padj < DEG_FDR & abs(tab$logFC) > DEG_LOG2FC, , drop = FALSE]

  write.csv(tab, file.path(out, "DEG_all.csv"), row.names = FALSE)
  write.csv(sig, file.path(out, "DEG_significant.csv"), row.names = FALSE)
  save_pca(v$E, md, file.path(out, "PCA_voom.png"), paste(d, cfg$gse_id, "voom PCA"))

  vol <- ggplot(tab, aes(logFC, -log10(pmax(padj, 1e-300)))) +
    geom_point(aes(color = padj < DEG_FDR & abs(logFC) > DEG_LOG2FC), alpha = .65, size = 1.2) +
    geom_vline(xintercept = c(-DEG_LOG2FC, DEG_LOG2FC), linetype = 2) +
    geom_hline(yintercept = -log10(DEG_FDR), linetype = 2) + theme_bw() +
    labs(title = paste(d, cfg$gse_id), x = "log2 fold change", y = "-log10 adjusted P", color = "Significant")
  ggsave(file.path(out, "Volcano.png"), vol, width = 7, height = 5.5, dpi = 300)

  cat("Samples:", ncol(v$E), "| genes:", nrow(v$E), "| significant DEGs:", nrow(sig), "| SVs:", n_sv, "\n")
  list(expr = v$E, metadata = md, deg_all = tab, sig_degs = sig, n_sv = n_sv)
}

deg_results <- lapply(names(analysis_list), function(d) run_deg(d, analysis_list[[d]])); names(deg_results) <- names(analysis_list)

# ==========================================================
# 4. WGCNA ON THE SAME VOOM EXPRESSION
# ==========================================================

run_wgcna <- function(d, deg_obj) {
  cat("\n=== WGCNA: ", d, " ===\n", sep = "")
  out <- file.path(OUT_DIR, paste0("Phase2_WGCNA_", d)); dir.create(out, recursive = TRUE, showWarnings = FALSE)

  expr <- deg_obj$expr; md <- deg_obj$metadata
  vars <- matrixStats::rowVars(expr, na.rm = TRUE); names(vars) <- rownames(expr)
  genes <- names(sort(vars[is.finite(vars) & vars > 0], decreasing = TRUE))
  genes <- head(genes, min(WGCNA_TOP_VAR, length(genes)))
  datExpr <- t(expr[genes, , drop = FALSE])

  gsg <- WGCNA::goodSamplesGenes(datExpr, verbose = 0)
  datExpr <- datExpr[gsg$goodSamples, gsg$goodGenes, drop = FALSE]
  md <- md[match(rownames(datExpr), md[[sample_col]]), , drop = FALSE]
  if (nrow(datExpr) < 15L) warning(d, ": WGCNA sample size is small; interpret modules cautiously.")

  trait <- as.numeric(md[[condition_col]] == case_label)
  powers <- c(1:10, seq(12, 30, 2))
  cor_fnc <- if (WGCNA_COR == "bicor") "bicor" else "cor"
  cor_opts <- if (WGCNA_COR == "bicor") list(use = "p", maxPOutliers = 0.10) else list(use = "p")

  sft <- WGCNA::pickSoftThreshold(datExpr, powerVector = powers, networkType = WGCNA_NETWORK_TYPE,
                                  corFnc = cor_fnc, corOptions = cor_opts, verbose = 0)
  r2 <- -sign(sft$fitIndices[,3]) * sft$fitIndices[,2]
  ok <- which(r2 >= 0.80)
  power <- if (length(ok)) sft$fitIndices[min(ok),1] else sft$fitIndices[which.max(r2),1]

  net <- WGCNA::blockwiseModules(
    datExpr, power = power, maxBlockSize = max(5000L, ncol(datExpr)),
    networkType = WGCNA_NETWORK_TYPE, TOMType = WGCNA_NETWORK_TYPE,
    corType = WGCNA_COR, minModuleSize = WGCNA_MIN_MODULE,
    deepSplit = WGCNA_DEEP_SPLIT, mergeCutHeight = WGCNA_MERGE_HEIGHT,
    reassignThreshold = 0, numericLabels = FALSE, pamRespectsDendro = FALSE,
    verbose = 0
  )

  colors <- net$colors; names(colors) <- colnames(datExpr)
  MEs <- WGCNA::orderMEs(net$MEs)
  mt_cor <- as.numeric(WGCNA::cor(MEs, trait, use = "p"))
  mt_p <- as.numeric(WGCNA::corPvalueStudent(matrix(mt_cor), nrow(datExpr)))
  module_names <- sub("^ME", "", colnames(MEs))
  module_table <- data.frame(Module = module_names, Correlation = mt_cor, P_value = mt_p,
                             FDR = p.adjust(mt_p, "BH"), stringsAsFactors = FALSE)
  module_table <- module_table[module_table$Module != "grey", ]
  sig_modules <- module_table$Module[module_table$P_value < WGCNA_MODULE_P]

  gs <- as.numeric(WGCNA::cor(datExpr, trait, use = "p")); names(gs) <- colnames(datExpr)
  mm_mat <- as.matrix(WGCNA::cor(datExpr, MEs, use = "p")); rownames(mm_mat) <- colnames(datExpr)
  own_mm <- vapply(colnames(datExpr), function(g) {
    col <- paste0("ME", colors[g]); if (col %in% colnames(mm_mat)) mm_mat[g, col] else NA_real_
  }, numeric(1))

  gene_id <- colnames(datExpr)
  symbol_map <- deg_obj$deg_all$gene_symbol[match(gene_id, deg_obj$deg_all$gene_id)]
  symbol_map[is.na(symbol_map)] <- gene_id[is.na(symbol_map)]

  gtab <- data.frame(
    gene_id = gene_id, gene_symbol = clean_gene(symbol_map), Module = unname(colors[gene_id]),
    MM = own_mm, GS = gs[gene_id], stringsAsFactors = FALSE
  )
  gtab$Significant_Module <- gtab$Module %in% sig_modules
  gtab$WGCNA_raw <- abs(gtab$MM) * abs(gtab$GS)
  gtab$S_WGCNA <- minmax01(gtab$WGCNA_raw)
  gtab <- gtab[!is.na(gtab$gene_symbol), ]; gtab <- gtab[order(-gtab$S_WGCNA), ]; gtab <- gtab[!duplicated(gtab$gene_symbol), ]
  sig_genes <- gtab[gtab$Significant_Module & gtab$Module != "grey", , drop = FALSE]

  write.csv(module_table, file.path(out, "module_trait.csv"), row.names = FALSE)
  write.csv(gtab, file.path(out, "WGCNA_all_genes.csv"), row.names = FALSE)
  write.csv(sig_genes, file.path(out, "WGCNA_significant_module_genes.csv"), row.names = FALSE)

  cat("Soft power:", power, "| modules:", nrow(module_table), "| significant modules:", length(sig_modules),
      "| supported genes:", nrow(sig_genes), "\n")
  list(all_genes = gtab, sig_module_genes = sig_genes, modules = module_table, soft_power = power)
}

wgcna_results <- lapply(names(deg_results), function(d) run_wgcna(d, deg_results[[d]])); names(wgcna_results) <- names(deg_results)

# ==========================================================
# 5. SHARED DEG + WGCNA CANDIDATE INTEGRATION
# ==========================================================

cat("\n=== DEG + WGCNA integration ===\n")
datasets <- names(analysis_list)
shared_deg <- Reduce(intersect, lapply(datasets, function(d) unique(clean_gene(deg_results[[d]]$sig_degs$gene_symbol))))
shared_deg <- shared_deg[!is.na(shared_deg)]
if (!length(shared_deg)) stop("No three-way shared significant DEGs under current thresholds.")

cand <- data.frame(Gene = shared_deg, stringsAsFactors = FALSE)
for (d in datasets) {
  de <- deg_results[[d]]$deg_all %>% select(gene_symbol, logFC, padj, S_DEG) %>% distinct(gene_symbol, .keep_all = TRUE)
  names(de) <- c("Gene", paste0("logFC_", d), paste0("padj_", d), paste0("S_DEG_", d))
  wg <- wgcna_results[[d]]$sig_module_genes %>% select(gene_symbol, Module, MM, GS, S_WGCNA) %>% distinct(gene_symbol, .keep_all = TRUE)
  names(wg) <- c("Gene", paste0("Module_", d), paste0("MM_", d), paste0("GS_", d), paste0("S_WGCNA_", d))
  cand <- cand %>% left_join(de, by = "Gene") %>% left_join(wg, by = "Gene")
}

sd_cols <- paste0("S_DEG_", datasets); sw_cols <- paste0("S_WGCNA_", datasets); lfc_cols <- paste0("logFC_", datasets)
cand$S_DEG <- rowMeans(as.matrix(cand[, sd_cols]), na.rm = TRUE)
cand$WGCNA_support_count <- rowSums(!is.na(cand[, sw_cols, drop = FALSE]))
for (x in sw_cols) cand[[x]][is.na(cand[[x]])] <- 0
cand$S_WGCNA <- rowMeans(as.matrix(cand[, sw_cols, drop = FALSE]))
cand$Same_direction <- apply(as.matrix(cand[, lfc_cols]), 1, function(x) all(sign(x) == sign(x[1])))
cand <- cand[cand$WGCNA_support_count >= WGCNA_SUPPORT_MIN, , drop = FALSE]
if (!nrow(cand)) stop("No candidates meet WGCNA_SUPPORT_MIN = ", WGCNA_SUPPORT_MIN, ". Change only as a prespecified sensitivity analysis.")
cand <- cand[order(-rowMeans(cbind(cand$S_DEG, cand$S_WGCNA))), ]

phase3_dir <- file.path(OUT_DIR, "Phase3_DEG_WGCNA_candidates"); dir.create(phase3_dir, recursive = TRUE, showWarnings = FALSE)
write.csv(cand, file.path(phase3_dir, "DEG_WGCNA_candidates.csv"), row.names = FALSE)
cat("Shared DEGs:", length(shared_deg), "| final DEG-WGCNA candidates:", nrow(cand), "\n")
if (nrow(cand) < 3L) stop("TD-CCHI requires at least 3 candidate genes.")

# ==========================================================
# 6. EXPORT NORMALIZED MODEL INPUTS
# ==========================================================

model_dir <- file.path(OUT_DIR, "ModelInputs"); dir.create(model_dir, recursive = TRUE, showWarnings = FALSE)
model_inputs <- setNames(lapply(datasets, function(d) {
  expr <- deg_results[[d]]$expr
  id <- rownames(expr)
  sym <- deg_results[[d]]$deg_all$gene_symbol[match(id, deg_results[[d]]$deg_all$gene_id)]
  sym[is.na(sym)] <- id[is.na(sym)]
  efile <- file.path(model_dir, paste0(d, "_expression.csv"))
  mfile <- file.path(model_dir, paste0(d, "_metadata.csv"))
  write.csv(data.frame(probe_id = id, gene_symbol = clean_gene(sym), expr, check.names = FALSE), efile, row.names = FALSE)
  md <- deg_results[[d]]$metadata
  write.csv(data.frame(Samples = md[[sample_col]], Condition = as.character(md[[condition_col]])), mfile, row.names = FALSE)
  list(expression = efile, metadata = mfile)
}), datasets)

candidate_file <- file.path(model_dir, "TD_CCHI_candidates.csv")
write.csv(data.frame(Gene = cand$Gene), candidate_file, row.names = FALSE)

# ==========================================================
# 7. TD-CCHI CUSTOM GNN — PURE R/torch, PAIRWISE ACROSS DATASETS
# ==========================================================

GNN_SCRIPT <- file.path(SCRIPT_DIR, "TD_CCHI_GNN_R.R")
phase4_dir <- file.path(OUT_DIR, "Phase4_TD_CCHI_GNN")
dir.create(phase4_dir, recursive = TRUE, showWarnings = FALSE)

if (!RUN_GNN) stop("RUN_GNN must be TRUE for the final discovery pipeline.")
if (!file.exists(GNN_SCRIPT)) stop("Pure-R GNN module not found beside master script: ", GNN_SCRIPT)
source(GNN_SCRIPT)

run_gnn_pair <- function(a, b) {
  pair <- paste0(a, "_vs_", b)
  od <- file.path(phase4_dir, pair)
  dir.create(od, recursive = TRUE, showWarnings = FALSE)

  fit <- run_td_cchi_r(
    cohort1_expression = model_inputs[[a]]$expression,
    cohort1_metadata = model_inputs[[a]]$metadata,
    cohort2_expression = model_inputs[[b]]$expression,
    cohort2_metadata = model_inputs[[b]]$metadata,
    candidate_gene_file = candidate_file,
    cohort1_name = a,
    cohort2_name = b,
    output_dir = od,
    bootstraps = GNN_BOOTSTRAPS,
    top_fraction = GNN_TOP_FRACTION,
    warmup_epochs = GNN_WARMUP_EPOCHS,
    cluster_epochs = GNN_CLUSTER_EPOCHS,
    patience = GNN_PATIENCE,
    seed = 20260908L + match(a, datasets) * 1000L + match(b, datasets) * 100L,
    device = "auto",
    verbose = TRUE
  )

  x <- fit$results
  x$Pair <- pair
  x$Pair_Top <- x$Rank <= max(1L, ceiling(nrow(x) * GNN_TOP_FRACTION))
  x
}

pairs <- combn(datasets, 2, simplify = FALSE)
gnn_long <- bind_rows(lapply(pairs, function(p) run_gnn_pair(p[1], p[2])))
write.csv(gnn_long, file.path(phase4_dir, "TD_CCHI_pairwise_long.csv"), row.names = FALSE)

gnn <- gnn_long %>% group_by(Gene) %>% summarise(
  S_GNN = mean(CCHS, na.rm = TRUE), GNN_SD = sd(CCHS, na.rm = TRUE),
  GNN_PairTopSupport = sum(Pair_Top, na.rm = TRUE),
  GNN_C = mean(Centrality_C, na.rm = TRUE), GNN_I = mean(InterCluster_I, na.rm = TRUE),
  GNN_S = mean(Stability_S, na.rm = TRUE), GNN_R = mean(Reproducibility_R, na.rm = TRUE), .groups = "drop"
) %>% arrange(desc(S_GNN), desc(GNN_PairTopSupport))
write.csv(gnn, file.path(phase4_dir, "TD_CCHI_aggregate.csv"), row.names = FALSE)

gnn_hubs <- head(gnn, min(GNN_TOP_N_FOR_ML, nrow(gnn)))
gnn_hub_file <- file.path(phase4_dir, "TD_CCHI_hubs_for_113ML.csv")
write.csv(data.frame(Gene = gnn_hubs$Gene), gnn_hub_file, row.names = FALSE)
cat("TD-CCHI pure-R hubs entering ML:", nrow(gnn_hubs), "\n")

# ==========================================================
# 8. 113-MODEL ML — INTERNAL NESTED CV PER DATASET
# ==========================================================

ML_SCRIPT <- file.path(SCRIPT_DIR, "TriDiseaseRankX_113ML_Internal.R")
phase5_dir <- file.path(OUT_DIR, "Phase5_113ML"); dir.create(phase5_dir, recursive = TRUE, showWarnings = FALSE)
if (!RUN_ML) stop("RUN_ML must be TRUE for final fusion.")
if (!file.exists(ML_SCRIPT)) stop("113-ML module not found beside master script: ", ML_SCRIPT)
source(ML_SCRIPT)

ml_results <- setNames(lapply(seq_along(datasets), function(i) {
  d <- datasets[i]; cat("\n=== 113-ML: ", d, " ===\n", sep = "")
  run_113ml_internal(
    expression_file = model_inputs[[d]]$expression,
    metadata_file = model_inputs[[d]]$metadata,
    candidate_gene_file = gnn_hub_file,
    dataset_name = d,
    output_dir = file.path(phase5_dir, d),
    outer_folds = ML_OUTER_FOLDS, inner_folds = ML_INNER_FOLDS,
    tuning_len = ML_TUNING_LENGTH, workers = ML_WORKERS,
    consensus_top_models = ML_TOP_MODELS, seed = 20260908L + i * 10000L
  )
}), datasets)

ml_long <- bind_rows(lapply(datasets, function(d) transform(ml_results[[d]]$gene_scores, Dataset = d)))
ml <- ml_long %>% select(Gene, Dataset, S_ML_Disease) %>%
  pivot_wider(names_from = Dataset, values_from = S_ML_Disease, names_prefix = "S_ML_")
for (nm in paste0("S_ML_", datasets)) { if (!nm %in% names(ml)) ml[[nm]] <- 0; ml[[nm]][is.na(ml[[nm]])] <- 0 }
ml$S_ML <- rowMeans(as.matrix(ml[, paste0("S_ML_", datasets), drop = FALSE]))
ml$ML_DatasetSupport <- rowSums(as.matrix(ml[, paste0("S_ML_", datasets), drop = FALSE]) > 0)
ml <- ml[order(-ml$S_ML), ]
write.csv(ml_long, file.path(phase5_dir, "113ML_gene_scores_long.csv"), row.names = FALSE)
write.csv(ml, file.path(phase5_dir, "113ML_aggregate.csv"), row.names = FALSE)

# ==========================================================
# 8A. INDEPENDENT EXTERNAL VALIDATION OF TOP 113-ML GENES
# ==========================================================
# ADDITION ONLY. The original 113-model internal engine above is unchanged.
# Each disease's top ML-ranked genes are selected using discovery results ONLY.
# A new prespecified ridge logistic classifier is fitted on discovery counts;
# it is NOT a previously saved 113-model classifier, and it is NOT a test of
# all 113 algorithms. The classifier, feature order, lambda and 0.50 threshold
# are frozen BEFORE external data are opened.
#
# External phenotype caveats:
#   D1: GSE203507 primary = villous EOPE vs iPTB (8 vs 5); other villous and
#       decidual composite comparisons are sensitivity analyses only.
#   D2: GSE120852 ventricular failure -> GSE208592 PAH lung is a DIFFERENT
#       phenotype and tissue, not systemic hypertension diagnosis.
#   D3: GSE161349 mutation-background CRC spheres -> GSE100243 tumor/normal
#       tissues is a cross-phenotype transfer, not clinical CRC diagnosis.
# ==========================================================

TDRX_ML_VALIDATION_CONFIG <- list(
  D1 = list(discovery = "GSE172381", external = "GSE203507",
            interpretation = "Exploratory EOPE-vs-iPTB villous placenta transfer"),
  D2 = list(discovery = "GSE120852", external = "GSE208592",
            interpretation = "Exploratory ventricular-failure heart to PAH lung transfer; NOT systemic HTN diagnosis"),
  D3 = list(discovery = "GSE161349", external = "GSE100243",
            interpretation = "Exploratory CRC genotype-background spheres to tumor-vs-normal tissue transfer")
)

TDRX_ML_EXTERNAL_DIR <- file.path(OUT_DIR, "Phase5B_113ML_TopGenes_Independent_Validation")
dir.create(TDRX_ML_EXTERNAL_DIR, showWarnings = FALSE, recursive = TRUE)

tdrx_write_csv <- function(x, path) {
  utils::write.csv(x, path, row.names = FALSE, na = "")
}

tdrx_validation_input <- function(gse, suffix) {
  resolve_input(paste0(gse, "_", suffix, ".csv"))
}

tdrx_validation_metadata <- function(path, cohort) {
  x <- data.table::fread(path, data.table = FALSE, check.names = FALSE)
  names(x) <- trimws(names(x))
  if (!all(c("Samples", "Condition") %in% names(x))) {
    stop(cohort, ": Samples and Condition columns are required")
  }
  x$Samples <- trimws(as.character(x$Samples))
  x$Condition <- trimws(as.character(x$Condition))
  if (anyNA(x$Samples) || any(!nzchar(x$Samples)) || anyDuplicated(x$Samples)) {
    stop(cohort, ": invalid or duplicated sample IDs")
  }
  if (!all(x$Condition %in% c("Control", "Case")) ||
      !all(c("Control", "Case") %in% x$Condition)) {
    stop(cohort, ": both Control and Case are required")
  }
  x
}

# Every sample's library-size denominator includes ALL count-table genes,
# not just the selected ML genes. No validation-label-dependent normalization.
tdrx_validation_logcpm <- function(count_path, md, genes, cohort) {
  tab <- data.table::fread(count_path, data.table = FALSE, check.names = FALSE,
                           showProgress = FALSE)
  if (!"gene_symbol" %in% names(tab)) stop(cohort, ": gene_symbol column absent")
  if (anyDuplicated(names(tab))) stop(cohort, ": duplicate count-table columns")
  if (!all(md$Samples %in% names(tab))) {
    stop(cohort, ": metadata samples absent from counts: ",
         paste(setdiff(md$Samples, names(tab)), collapse = ", "))
  }
  sym <- toupper(trimws(as.character(tab$gene_symbol)))
  sym <- sub("[[:space:]]*(///|//|;|\\|).*$", "", sym)
  vals <- as.matrix(tab[, md$Samples, drop = FALSE])
  suppressWarnings(storage.mode(vals) <- "double")
  if (any(!is.finite(vals)) || any(vals < 0)) {
    stop(cohort, ": nonfinite or negative counts")
  }
  if (any(abs(vals - round(vals)) > 1e-6)) {
    stop(cohort, ": noninteger values; counts rather than TPM/FPKM are required")
  }
  lib <- colSums(vals)
  if (any(!is.finite(lib) | lib <= 0)) stop(cohort, ": invalid library sizes")
  gene_counts <- matrix(0, nrow = length(genes), ncol = nrow(md),
                        dimnames = list(genes, md$Samples))
  audit <- vector("list", length(genes))
  for (i in seq_along(genes)) {
    ix <- which(!is.na(sym) & sym == genes[i])
    if (!length(ix)) stop(cohort, ": frozen ML-ranked gene absent: ", genes[i])
    gene_counts[i, ] <- colSums(vals[ix, , drop = FALSE])
    audit[[i]] <- data.frame(Cohort = cohort, Gene = genes[i],
                             Matched_Rows = length(ix),
                             Zero_Count_Samples = sum(gene_counts[i, ] == 0),
                             All_Zero = all(gene_counts[i, ] == 0),
                             stringsAsFactors = FALSE)
  }
  x <- t(log2(sweep(gene_counts, 2, lib / 1e6, "/") + 1))
  x <- x[md$Samples, genes, drop = FALSE]
  if (any(!is.finite(x))) stop(cohort, ": nonfinite transformed expression")
  list(X = x, audit = do.call(rbind, audit))
}

tdrx_fold_ids <- function(y, k, seed) {
  set.seed(seed)
  fold <- integer(length(y))
  for (cl in 0:1) {
    ix <- which(y == cl)
    fold[ix] <- sample(rep(seq_len(k), length.out = length(ix)))
  }
  fold
}

tdrx_train_frozen_topgenes <- function(X, md, genes, input_paths, model_path,
                                       dataset, seed) {
  hashes <- setNames(unname(tools::md5sum(input_paths)), basename(input_paths))
  if (anyNA(hashes)) stop(dataset, ": could not hash discovery inputs")
  if (file.exists(model_path)) {
    locked <- readRDS(model_path)
    if (!identical(locked$genes, genes) ||
        !identical(locked$discovery_md5, hashes) ||
        !identical(locked$threshold, 0.5) ||
        !identical(locked$lambda_rule, "lambda.1se") ||
        !identical(locked$algorithm, "Ridge_logistic_alpha_0")) {
      stop(dataset, ": existing frozen model differs from discovery inputs or settings. ",
           "Use a NEW versioned results folder; never silently retrain after validation.")
    }
    cat("[External ML] Reusing locked model: ", dataset, "\n", sep = "")
    return(locked)
  }
  y <- as.integer(md$Condition == "Case")
  if (nrow(X) != nrow(md) || !identical(rownames(X), md$Samples)) {
    stop(dataset, ": discovery X/metadata order mismatch")
  }
  k <- min(5L, min(tabulate(y + 1L, nbins = 2L)))
  if (k < 3L) stop(dataset, ": fewer than three discovery samples in a class")
  foldid <- tdrx_fold_ids(y, k, seed)
  set.seed(seed)
  fit <- glmnet::cv.glmnet(x = X, y = y, family = "binomial", alpha = 0,
                            nfolds = k, foldid = foldid,
                            type.measure = "deviance", standardize = TRUE)
  locked <- list(
    algorithm = "Ridge_logistic_alpha_0",
    source = "Top genes from discovery-only 113ML S_ML_Disease ranking",
    dataset = dataset, genes = genes, transform = "per_sample_log2_CPM_plus_1",
    lambda_rule = "lambda.1se", threshold = 0.5,
    threshold_rule = "Prespecified_fixed_0.50_no_external_tuning",
    fitted = fit, discovery_md5 = hashes,
    discovery_cases = sum(y == 1L), discovery_controls = sum(y == 0L),
    locked_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
  )
  # No external metadata, counts or labels have been accessed yet.
  saveRDS(locked, model_path)
  cat("[External ML] FROZEN: ", dataset, " | genes=",
      paste(genes, collapse = ","), " | threshold=0.50\n", sep = "")
  locked
}

tdrx_predict_frozen_topgenes <- function(locked, X) {
  if (!identical(colnames(X), locked$genes)) stop("Frozen feature order mismatch")
  p <- as.numeric(stats::predict(locked$fitted, newx = X,
                                 s = locked$lambda_rule, type = "response"))
  if (length(p) != nrow(X) || any(!is.finite(p)) || any(p < 0 | p > 1)) {
    stop("Invalid external model probabilities")
  }
  p
}

tdrx_external_comparisons <- function(gse, supplied) {
  if (gse != "GSE203507") {
    if (gse == "GSE208592") {
      mf_path <- file.path(DATA_DIR, "GSE208592_verified_lung_manifest.csv")
      if (file.exists(mf_path)) {
        mf <- tdrx_validation_metadata(mf_path, gse)
        ix <- match(supplied$Samples, mf$Samples)
        if (anyNA(ix) || any(supplied$Condition != mf$Condition[ix])) {
          stop(gse, ": PAH phenotype manifest contradicts supplied metadata")
        }
      }
    }
    return(list(PRIMARY = supplied))
  }

  # Predefined clinical-group and tissue comparison. No outcome/model score
  # is used to choose which samples are evaluated.
  manifest_path <- file.path(DATA_DIR, "GSE203507_verified_group_manifest.csv")
  if (file.exists(manifest_path)) {
    mf <- tdrx_validation_metadata(manifest_path, gse)
  } else if (all(c("tissue", "clinical group") %in% names(supplied))) {
    mf <- supplied
    mf$Tissue <- as.character(mf[["tissue"]])
    mf$Clinical_Group <- as.character(mf[["clinical group"]])
  } else {
    stop("GSE203507 requires its verified phenotype manifest or metadata with ",
         "tissue and clinical group. Do not treat FGR-only as pure PE.")
  }
  if (!all(c("Tissue", "Clinical_Group") %in% names(mf))) {
    stop("GSE203507 manifest missing Tissue/Clinical_Group")
  }
  ix <- match(supplied$Samples, mf$Samples)
  if (anyNA(ix) || any(supplied$Condition != mf$Condition[ix])) {
    stop("GSE203507 manifest contradicts supplied sample labels")
  }
  mf <- mf[ix, , drop = FALSE]
  villous <- mf[mf$Tissue == "placenta, villous tissue", , drop = FALSE]
  decidua <- mf[mf$Tissue == "placenta, decidua basalis", , drop = FALSE]
  primary <- villous[villous$Clinical_Group %in% c("EOPE", "iPTB"), , drop = FALSE]
  if (!all(primary$Condition[primary$Clinical_Group == "EOPE"] == "Case") ||
      !all(primary$Condition[primary$Clinical_Group == "iPTB"] == "Control")) {
    stop("GSE203507 EOPE/iPTB primary labels are inconsistent")
  }
  if (nrow(primary) < 4L || !all(c("Case", "Control") %in% primary$Condition)) {
    stop("GSE203507 primary EOPE-vs-iPTB comparison has insufficient groups")
  }
  result <- list(PRIMARY = primary)
  if (all(c("Case", "Control") %in% villous$Condition) && nrow(villous) > nrow(primary)) {
    result$SENSITIVITY_VILLOUS_COMPOSITE <- villous
  }
  if (nrow(decidua) >= 4L && all(c("Case", "Control") %in% decidua$Condition)) {
    result$SENSITIVITY_DECIDUA_COMPOSITE <- decidua
  }
  result
}

tdrx_auc <- function(y, p) {
  a <- p[y == 1L]; b <- p[y == 0L]
  if (!length(a) || !length(b)) return(NA_real_)
  mean(outer(a, b, ">") + 0.5 * outer(a, b, "=="))
}

tdrx_auc_ci <- function(y, p, seed, nboot = 2000L) {
  if (length(unique(p)) < 2L) return(list(lo = NA_real_, hi = NA_real_, method = "constant_scores"))
  roc <- pROC::roc(response = factor(y, levels = c(0, 1)), predictor = p,
                   levels = c("0", "1"), direction = "<", quiet = TRUE)
  ci <- tryCatch(suppressWarnings(as.numeric(pROC::ci.auc(
    roc, conf.level = 0.95, method = "delong"))), error = function(e) numeric())
  if (length(ci) == 3L && all(is.finite(ci)) && ci[1] <= ci[3]) {
    return(list(lo = ci[1], hi = ci[3], method = "DeLong"))
  }
  set.seed(seed)
  a <- which(y == 1L); b <- which(y == 0L)
  z <- replicate(nboot, {
    idx <- c(sample(a, length(a), replace = TRUE),
             sample(b, length(b), replace = TRUE))
    tdrx_auc(y[idx], p[idx])
  })
  ci <- as.numeric(stats::quantile(z, c(0.025, 0.975), na.rm = TRUE))
  list(lo = ci[1], hi = ci[2], method = "Stratified_bootstrap")
}

tdrx_ba_ci <- function(y, pred, seed, nboot = 2000L) {
  set.seed(seed)
  a <- which(y == 1L); b <- which(y == 0L)
  z <- replicate(nboot, {
    ai <- sample(a, length(a), replace = TRUE)
    bi <- sample(b, length(b), replace = TRUE)
    (mean(pred[ai] == 1L) + mean(pred[bi] == 0L)) / 2
  })
  as.numeric(stats::quantile(z, c(0.025, 0.975), na.rm = TRUE))
}

tdrx_calibration_stats <- function(y, p) {
  result <- list(brier = mean((y - p)^2), intercept = NA_real_,
                 slope = NA_real_, status = "Descriptive_only_small_or_nonindependent_cohort")
  # Formal calibration is not credible for the supplied small external cohorts.
  # Only attempt when there is sufficient sample size and no known pairing.
  if (length(y) < 100L || min(table(y)) < 30L || length(unique(p)) < 10L) {
    return(result)
  }
  lp <- stats::qlogis(pmin(pmax(p, 1e-6), 1 - 1e-6))
  ai <- tryCatch(suppressWarnings(stats::glm(y ~ 1 + offset(lp),
                                                  family = stats::binomial())),
                 error = function(e) NULL)
  sl <- tryCatch(suppressWarnings(stats::glm(y ~ lp,
                                                  family = stats::binomial())),
                 error = function(e) NULL)
  if (!is.null(ai) && !is.null(sl) &&
      all(is.finite(stats::coef(ai))) && all(is.finite(stats::coef(sl)))) {
    result$intercept <- as.numeric(stats::coef(ai)[1])
    result$slope <- as.numeric(stats::coef(sl)[2])
    result$status <- "Exploratory_formal_fit"
  }
  result
}

tdrx_save_tiff_plot <- function(p, path, width = 7.2, height = 5.5) {
  ggplot2::ggsave(filename = path, plot = p, device = "tiff",
                  width = width, height = height, units = "in",
                  dpi = 300, compression = "lzw", bg = "white")
}

tdrx_external_evaluate <- function(locked, X, md, output_dir, gse, analysis,
                                   interpretation, seed) {
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  if (!all(md$Samples %in% rownames(X))) stop("External X/metadata sample mismatch")
  X <- X[md$Samples, locked$genes, drop = FALSE]
  y <- as.integer(md$Condition == "Case")
  if (min(table(y)) < 2L) stop("At least two external samples per class are required")
  p <- tdrx_predict_frozen_topgenes(locked, X)
  pred <- as.integer(p >= locked$threshold)
  TP <- sum(y == 1L & pred == 1L); FN <- sum(y == 1L & pred == 0L)
  TN <- sum(y == 0L & pred == 0L); FP <- sum(y == 0L & pred == 1L)
  sens <- TP / (TP + FN); spec <- TN / (TN + FP)
  ci <- tdrx_auc_ci(y, p, seed)
  ci_s <- as.numeric(stats::binom.test(TP, TP + FN, conf.level = 0.95)$conf.int)
  ci_c <- as.numeric(stats::binom.test(TN, TN + FP, conf.level = 0.95)$conf.int)
  ci_b <- tdrx_ba_ci(y, pred, seed + 1L)
  cal <- tdrx_calibration_stats(y, p)
  auc <- tdrx_auc(y, p)
  metrics <- data.frame(
    Discovery_Dataset = locked$dataset, External_Dataset = gse,
    Analysis = analysis, Interpretation = interpretation,
    Model = locked$algorithm, Genes = paste(locked$genes, collapse = ";"),
    N = length(y), Cases = sum(y == 1L), Controls = sum(y == 0L),
    Threshold = locked$threshold,
    ROC_AUC = auc, ROC_AUC_95CI_Lower = ci$lo,
    ROC_AUC_95CI_Upper = ci$hi, ROC_AUC_CI_Method = ci$method,
    Sensitivity = sens, Sensitivity_95CI_Lower = ci_s[1],
    Sensitivity_95CI_Upper = ci_s[2],
    Specificity = spec, Specificity_95CI_Lower = ci_c[1],
    Specificity_95CI_Upper = ci_c[2],
    Balanced_Accuracy = (sens + spec) / 2,
    Balanced_Accuracy_95CI_Lower = ci_b[1],
    Balanced_Accuracy_95CI_Upper = ci_b[2],
    Accuracy = mean(pred == y), TP = TP, FP = FP, TN = TN, FN = FN,
    Brier_Score = cal$brier, Calibration_Intercept = cal$intercept,
    Calibration_Slope = cal$slope, Calibration_Status = cal$status,
    Small_N = length(y) < 50L,
    stringsAsFactors = FALSE
  )
  predictions <- data.frame(Samples = md$Samples, Observed = md$Condition,
                            Case_Probability = p, Frozen_Threshold = locked$threshold,
                            Predicted = ifelse(pred == 1L, "Case", "Control"),
                            Correct = pred == y, stringsAsFactors = FALSE)
  for (extra in intersect(c("Clinical_Group", "Tissue"), names(md))) {
    predictions[[extra]] <- md[[extra]]
  }
  tdrx_write_csv(metrics, file.path(output_dir, "external_metrics.csv"))
  tdrx_write_csv(predictions, file.path(output_dir, "external_predictions.csv"))
  tdrx_write_csv(data.frame(Observed = c("Control", "Case"),
                             Predicted_Control = c(TN, FN),
                             Predicted_Case = c(FP, TP)),
                 file.path(output_dir, "confusion_matrix.csv"))
  tdrx_write_csv(md, file.path(output_dir, "external_metadata_used.csv"))

  # Publication figures are generated directly as 300-dpi LZW TIFF.
  if (length(unique(p)) >= 2L) {
    roc <- pROC::roc(response = factor(y, levels = c(0, 1)), predictor = p,
                     levels = c("0", "1"), direction = "<", quiet = TRUE)
    r <- data.frame(FPR = 1 - roc$specificities, TPR = roc$sensitivities)
    r <- r[order(r$FPR, r$TPR), , drop = FALSE]
    subtitle <- if (is.finite(ci$lo) && is.finite(ci$hi)) {
      sprintf("AUC %.3f (95%% CI %.3f to %.3f)", auc, ci$lo, ci$hi)
    } else sprintf("AUC %.3f (95%% CI unavailable)", auc)
    rocplot <- ggplot2::ggplot(r, ggplot2::aes(FPR, TPR)) +
      ggplot2::geom_step(color = "#1F5A7A", linewidth = 1.1) +
      ggplot2::geom_abline(intercept = 0, slope = 1, linetype = 2, color = "grey55") +
      ggplot2::coord_equal(xlim = c(0, 1), ylim = c(0, 1)) +
      ggplot2::theme_bw(base_size = 12) +
      ggplot2::labs(title = paste(gse, analysis, "ROC"), subtitle = subtitle,
                    x = "1 - Specificity", y = "Sensitivity")
  } else {
    rocplot <- ggplot2::ggplot(data.frame(x = 0.5, y = 0.5), ggplot2::aes(x, y)) +
      ggplot2::geom_text(label = "Constant scores: ROC not informative") +
      ggplot2::theme_void() + ggplot2::labs(title = paste(gse, analysis, "ROC"))
  }
  tdrx_save_tiff_plot(rocplot, file.path(output_dir, "ROC_AUC_95CI.tiff"))

  cm <- data.frame(Observed = factor(rep(c("Control", "Case"), each = 2),
                                    levels = c("Case", "Control")),
                   Predicted = factor(rep(c("Control", "Case"), 2),
                                      levels = c("Control", "Case")),
                   N = c(TN, FP, FN, TP))
  cp <- ggplot2::ggplot(cm, ggplot2::aes(Predicted, Observed, fill = N)) +
    ggplot2::geom_tile(color = "white", linewidth = 1.5) +
    ggplot2::geom_text(ggplot2::aes(label = N), size = 7) +
    ggplot2::scale_fill_gradient(low = "#E7F0F4", high = "#5486A3") +
    ggplot2::coord_equal() + ggplot2::theme_minimal(base_size = 12) +
    ggplot2::labs(title = paste(gse, analysis, "Confusion matrix"))
  tdrx_save_tiff_plot(cp, file.path(output_dir, "Confusion_Matrix.tiff"), 6, 5.5)

  bins <- cut(p, breaks = c(-1e-8, 1/3, 2/3, 1 + 1e-8),
              labels = c("Low", "Middle", "High"), include.lowest = TRUE)
  caltab <- do.call(rbind, lapply(levels(bins), function(b) {
    ix <- which(as.character(bins) == b)
    if (!length(ix)) return(NULL)
    data.frame(Bin = b, N = length(ix), Predicted_Mean = mean(p[ix]),
               Observed_Rate = mean(y[ix]))
  }))
  tdrx_write_csv(caltab, file.path(output_dir, "calibration_bins.csv"))
  calplot <- ggplot2::ggplot(caltab, ggplot2::aes(Predicted_Mean, Observed_Rate)) +
    ggplot2::geom_abline(slope = 1, intercept = 0, linetype = 2, color = "grey55") +
    ggplot2::geom_point(size = 3, color = "#1F5A7A") +
    ggplot2::geom_text(ggplot2::aes(label = paste0("n=", N)), vjust = -0.9) +
    ggplot2::coord_equal(xlim = c(0, 1), ylim = c(0, 1)) +
    ggplot2::theme_bw(base_size = 12) +
    ggplot2::labs(title = paste(gse, analysis, "Calibration"),
                  subtitle = "Fixed probability bins; descriptive only for small cohorts",
                  x = "Mean predicted Case probability", y = "Observed Case proportion")
  tdrx_save_tiff_plot(calplot, file.path(output_dir, "Calibration_Descriptive.tiff"))

  sc <- data.frame(Condition = factor(md$Condition, levels = c("Control", "Case")),
                   Probability = p)
  scoreplot <- ggplot2::ggplot(sc, ggplot2::aes(Condition, Probability, fill = Condition)) +
    ggplot2::geom_boxplot(alpha = 0.45, outlier.shape = NA, width = 0.55) +
    ggplot2::geom_jitter(width = 0.12, height = 0, size = 2, alpha = 0.75) +
    ggplot2::scale_y_continuous(limits = c(0, 1)) +
    ggplot2::theme_bw(base_size = 12) + ggplot2::theme(legend.position = "none") +
    ggplot2::labs(title = paste(gse, analysis, "Locked model scores"),
                  y = "Predicted Case probability", x = "External label")
  tdrx_save_tiff_plot(scoreplot, file.path(output_dir, "Frozen_Score_Distribution.tiff"))
  cat("[External ML] ", gse, " ", analysis,
      " | AUC=", sprintf("%.3f", auc), " | sensitivity=", sprintf("%.3f", sens),
      " | specificity=", sprintf("%.3f", spec), "\n", sep = "")
  metrics
}

tdrx_validate_one_disease <- function(d, cfg, ml_result, seed) {
  folder <- file.path(TDRX_ML_EXTERNAL_DIR, d)
  dir.create(folder, showWarnings = FALSE, recursive = TRUE)
  ranks <- ml_result$gene_scores
  if (!all(c("Gene", "S_ML_Disease", "ML_TopModelSupportCount") %in% names(ranks))) {
    stop(d, ": missing 113-ML gene ranking columns")
  }
  ranks$Gene <- toupper(trimws(as.character(ranks$Gene)))
  ranks <- ranks[!is.na(ranks$Gene) & nzchar(ranks$Gene) &
                   is.finite(ranks$S_ML_Disease), , drop = FALSE]
  ranks <- ranks[order(-ranks$S_ML_Disease,
                       -ranks$ML_TopModelSupportCount, ranks$Gene), , drop = FALSE]
  ranks <- ranks[!duplicated(ranks$Gene), , drop = FALSE]
  genes <- head(ranks$Gene, ML_EXTERNAL_TOP_N)
  if (length(genes) < 2L) stop(d, ": fewer than 2 ML-ranked genes")
  chosen <- ranks[match(genes, ranks$Gene), , drop = FALSE]
  chosen$Rank <- seq_along(genes)
  tdrx_write_csv(chosen, file.path(folder, "FROZEN_113ML_top_ranked_genes.csv"))

  # Discovery is read and model locked before any external data are accessed.
  dc <- tdrx_validation_input(cfg$discovery, "counts_data")
  dm <- tdrx_validation_input(cfg$discovery, "metadata")
  discovery_md <- tdrx_validation_metadata(dm, cfg$discovery)
  discovery <- tdrx_validation_logcpm(dc, discovery_md, genes, cfg$discovery)
  tdrx_write_csv(discovery$audit, file.path(folder, "discovery_gene_coverage.csv"))
  gene_scores_path <- file.path(phase5_dir, d, "gene_ML_scores.csv")
  if (!file.exists(gene_scores_path)) stop("113-ML score source file absent: ", gene_scores_path)
  model_path <- file.path(folder, "LOCKED_ML_topgenes_ridge_model.rds")
  locked <- tdrx_train_frozen_topgenes(
    discovery$X, discovery_md, genes, c(dc, dm, gene_scores_path),
    model_path, cfg$discovery, seed)
  tdrx_write_csv(data.frame(Gene = locked$genes, Threshold = locked$threshold,
                            Algorithm = locked$algorithm, Lambda = locked$lambda_rule),
                 file.path(folder, "LOCKED_model_manifest.csv"))
  tdrx_write_csv(data.frame(Source = names(locked$discovery_md5),
                            MD5 = unname(locked$discovery_md5)),
                 file.path(folder, "LOCKED_discovery_input_hashes.csv"))

  # FIRST external read occurs below, AFTER saveRDS(model_path).
  ec <- tdrx_validation_input(cfg$external, "counts_data")
  em <- tdrx_validation_input(cfg$external, "metadata")
  external_md <- tdrx_validation_metadata(em, cfg$external)
  if (length(intersect(discovery_md$Samples, external_md$Samples))) {
    stop(d, ": discovery/external sample IDs overlap")
  }
  comparisons <- tdrx_external_comparisons(cfg$external, external_md)
  all_md <- external_md[external_md$Samples %in%
                          unique(unlist(lapply(comparisons, `[[`, "Samples"))), , drop = FALSE]
  external <- tdrx_validation_logcpm(ec, all_md, genes, cfg$external)
  tdrx_write_csv(external$audit, file.path(folder, "external_gene_coverage.csv"))
  phenotype_file <- if (cfg$external == "GSE203507") {
    file.path(DATA_DIR, "GSE203507_verified_group_manifest.csv")
  } else if (cfg$external == "GSE208592") {
    file.path(DATA_DIR, "GSE208592_verified_lung_manifest.csv")
  } else NA_character_
  external_files <- c(ec, em)
  if (!is.na(phenotype_file) && file.exists(phenotype_file)) {
    external_files <- c(external_files, phenotype_file)
  }
  hashes <- setNames(unname(tools::md5sum(external_files)), basename(external_files))
  ext_lock_file <- file.path(folder, "EXTERNAL_INPUT_MD5_LOCK.csv")
  current <- data.frame(Source = names(hashes), MD5 = unname(hashes))
  if (file.exists(ext_lock_file)) {
    old <- utils::read.csv(ext_lock_file, stringsAsFactors = FALSE)
    if (!identical(old$Source, current$Source) || !identical(old$MD5, current$MD5)) {
      stop(d, ": external files changed since first validation; use a new results folder")
    }
  } else tdrx_write_csv(current, ext_lock_file)

  tdrx_write_csv(data.frame(
    Gene = genes, Discovery_Mean_Log2CPM = colMeans(discovery$X),
    External_Mean_Log2CPM = colMeans(external$X),
    Discovery_SD_Log2CPM = apply(discovery$X, 2, stats::sd),
    External_SD_Log2CPM = apply(external$X, 2, stats::sd)),
    file.path(folder, "expression_domain_shift.csv"))

  gp <- ggplot2::ggplot(chosen, ggplot2::aes(
    x = stats::reorder(Gene, S_ML_Disease), y = S_ML_Disease)) +
    ggplot2::geom_col(fill = "#376D87") + ggplot2::coord_flip() +
    ggplot2::theme_bw(base_size = 12) +
    ggplot2::labs(title = paste(d, "Discovery 113-ML top genes"),
                  x = "Frozen gene", y = "Discovery ML selection score")
  tdrx_save_tiff_plot(gp, file.path(folder, "Discovery_ML_Top_Genes.tiff"), 7, 5)

  results <- lapply(seq_along(comparisons), function(i) {
    nm <- names(comparisons)[i]
    interpretation <- cfg$interpretation
    if (nm != "PRIMARY") interpretation <- paste(interpretation, "[SENSITIVITY COMPARISON]")
    tdrx_external_evaluate(
      locked, external$X, comparisons[[i]], file.path(folder, nm),
      cfg$external, nm, interpretation, seed + i * 101L)
  })
  result <- do.call(rbind, results)
  tdrx_write_csv(result, file.path(folder, "ALL_EXTERNAL_METRICS.csv"))
  result
}

if (isTRUE(RUN_ML_EXTERNAL)) {
  cat("\n=== Independent validation: 113-ML-ranked top genes ===\n")
  if (!requireNamespace("glmnet", quietly = TRUE) ||
      !requireNamespace("pROC", quietly = TRUE)) {
    stop("External ML validation requires glmnet and pROC")
  }
  validation_results <- lapply(seq_along(datasets), function(i) {
    d <- datasets[i]
    tryCatch({
      result <- tdrx_validate_one_disease(d, TDRX_ML_VALIDATION_CONFIG[[d]],
                                          ml_results[[d]], seed = 20261120L + i * 1000L)
      list(status = data.frame(Dataset = d, Status = "COMPLETED", Message = ""),
           metrics = result)
    }, error = function(e) {
      warning("Independent validation failed for ", d, ": ", conditionMessage(e))
      list(status = data.frame(Dataset = d, Status = "FAILED",
                               Message = conditionMessage(e)), metrics = NULL)
    })
  })
  status <- do.call(rbind, lapply(validation_results, `[[`, "status"))
  tdrx_write_csv(status, file.path(TDRX_ML_EXTERNAL_DIR, "ML_EXTERNAL_VALIDATION_STATUS.csv"))
  metrics_list <- Filter(Negate(is.null), lapply(validation_results, `[[`, "metrics"))
  if (length(metrics_list)) {
    tdrx_write_csv(do.call(rbind, metrics_list),
                   file.path(TDRX_ML_EXTERNAL_DIR, "ALL_DISEASE_EXTERNAL_METRICS.csv"))
  }
  cat("[External ML] Status: ",
      paste(paste(status$Dataset, status$Status, sep = "="), collapse = "; "), "\n", sep = "")
}


# ==========================================================
# 9. PATHWAY ENRICHMENT + CONVERGENCE
# ==========================================================

PATHWAY_SCRIPT <- file.path(SCRIPT_DIR, "TriDiseaseRankX_Pathway.R")
phase6_dir <- file.path(OUT_DIR, "Phase6_Pathway"); dir.create(phase6_dir, recursive = TRUE, showWarnings = FALSE)
if (!RUN_PATHWAY) stop("RUN_PATHWAY must be TRUE for final fusion.")
if (!file.exists(PATHWAY_SCRIPT)) stop("Pathway module not found beside master script: ", PATHWAY_SCRIPT)
source(PATHWAY_SCRIPT)

pathway_gene_lists <- setNames(lapply(datasets, function(d) {
  intersect(unique(clean_gene(deg_results[[d]]$sig_degs$gene_symbol)),
            unique(clean_gene(wgcna_results[[d]]$sig_module_genes$gene_symbol)))
}), datasets)
pathway_universe <- setNames(lapply(datasets, function(d) unique(na.omit(clean_gene(deg_results[[d]]$deg_all$gene_symbol)))), datasets)

pathway_result <- run_tdrx_pathway(
  disease_gene_lists = pathway_gene_lists,
  universe_gene_lists = pathway_universe,
  candidate_genes = cand$Gene,
  output_dir = phase6_dir,
  padj_cutoff = 0.05, pvalue_cutoff = 0.05, qvalue_cutoff = 0.20,
  min_gs_size = 5L, max_gs_size = 500L,
  run_reactome = TRUE, run_wikipathways = TRUE, run_disease_ontology = TRUE,
  top_terms_plot = 20L
)
pathway <- pathway_result$gene_scores

# ==========================================================
# 10. FIVE-LAYER TRIDISEASERANK-X FUSION
# ==========================================================

cat("\n=== Final TriDiseaseRank-X fusion ===\n")
phase7_dir <- file.path(OUT_DIR, "Phase7_Prioritized_Biomarkers"); dir.create(phase7_dir, recursive = TRUE, showWarnings = FALSE)

base <- cand %>% transmute(Gene, S_DEG = clamp01(S_DEG), S_WGCNA = clamp01(S_WGCNA), WGCNA_support_count) %>%
  inner_join(gnn, by = "Gene") %>% inner_join(ml, by = "Gene") %>%
  left_join(pathway %>% select(any_of(c("Gene", "S_Pathway", "PathwayCount", "DatasetPathwaySupport",
                                        "DatabaseSupport", "ConvergentPathwayCount", "SharedAllDatasetPathwayCount"))), by = "Gene")

base$S_GNN <- clamp01(base$S_GNN); base$S_ML <- clamp01(base$S_ML)
base$S_Pathway <- clamp01(ifelse(is.na(base$S_Pathway), 0, base$S_Pathway))

for (layer in names(PRIMARY_WEIGHTS)) {
  score_col <- paste0("S_", layer)
  base[[paste0("Contribution_", layer)]] <- PRIMARY_WEIGHTS[layer] * base[[score_col]]
}
base$TriDiseaseRankX_Score <- rowSums(base[, paste0("Contribution_", names(PRIMARY_WEIGHTS)), drop = FALSE])

rank_pct <- function(x) if (length(x) <= 1L) rep(1, length(x)) else 1 - (rank(-x, ties.method = "average") - 1) / (length(x) - 1)
rmat <- cbind(rank_pct(base$S_DEG), rank_pct(base$S_WGCNA), rank_pct(base$S_GNN), rank_pct(base$S_ML), rank_pct(base$S_Pathway))
base$RankFusion_Sensitivity <- rowMeans(rmat)
cmat <- as.matrix(base[, c("S_DEG", "S_WGCNA", "S_GNN", "S_ML", "S_Pathway")])
labels <- c("DEG", "WGCNA", "TD-CCHI GNN", "113-ML", "Pathway")
base$Strongest_Evidence <- labels[max.col(cmat, ties.method = "first")]
base$Weakest_Evidence <- labels[max.col(-cmat, ties.method = "first")]
base <- base %>% arrange(desc(TriDiseaseRankX_Score), desc(RankFusion_Sensitivity), Gene) %>% mutate(Final_Rank = row_number())

final_panel <- head(base, min(FINAL_TOP_N, nrow(base)))
write.csv(base, file.path(phase7_dir, "TriDiseaseRankX_full_ranking.csv"), row.names = FALSE)
write.csv(final_panel, file.path(phase7_dir, "TriDiseaseRankX_top_biomarkers.csv"), row.names = FALSE)
write.csv(data.frame(Gene = final_panel$Gene), file.path(phase7_dir, "TriDiseaseRankX_locked_panel_for_future_ANN.csv"), row.names = FALSE)
write.csv(data.frame(Layer = names(PRIMARY_WEIGHTS), Weight = as.numeric(PRIMARY_WEIGHTS)),
          file.path(phase7_dir, "TriDiseaseRankX_weights.csv"), row.names = FALSE)

openxlsx::write.xlsx(
  list(Final_Ranking = base, Top_Biomarkers = final_panel, DEG_WGCNA = cand,
       GNN = gnn, ML = ml, Pathway = pathway, Pathway_Convergence = pathway_result$convergence),
  file.path(phase7_dir, "TriDiseaseRankX_results.xlsx"), overwrite = TRUE
)

capture.output(sessionInfo(), file = file.path(phase7_dir, "sessionInfo.txt"))
cat("\n============================================================\n")
cat("TriDiseaseRank-X completed successfully.\n")
cat("Final ranking: ", file.path(phase7_dir, "TriDiseaseRankX_full_ranking.csv"), "\n", sep = "")
cat("Top biomarkers: ", file.path(phase7_dir, "TriDiseaseRankX_top_biomarkers.csv"), "\n", sep = "")
cat("ANN input: ", file.path(phase7_dir, "TriDiseaseRankX_locked_panel_for_future_ANN.csv"), "\n", sep = "")
cat("============================================================\n")


# ==========================================================
# 11. OPTIONAL FROZEN GNN EXTERNAL EVIDENCE CHECK
# ==========================================================
# The separate module is the same external GNN evidence add-on supplied
# previously; it does NOT retrain the original GNN and is NOT ML diagnosis.
if (isTRUE(RUN_GNN_EXTERNAL)) {
  cat("\n=== External GNN evidence and frozen-encoder assessment ===\n")
  gnn_validation_path <- file.path(SCRIPT_DIR, "TDR_GNN_External_Evidence_Validation.R")
  gnn_status <- data.frame(Status = "FAILED", Message = "GNN validation module absent")
  if (file.exists(gnn_validation_path)) {
    gnn_status <- tryCatch({
      Sys.setenv(TDRX_DATA_DIR = normalizePath(DATA_DIR, winslash = "/", mustWork = TRUE))
      sys.source(gnn_validation_path, envir = new.env(parent = globalenv()))
      data.frame(Status = "COMPLETED_SCRIPT", Message = "Check per-disease GNN_VALIDATION_STATUS.csv")
    }, error = function(e) {
      warning("External GNN evidence module failed: ", conditionMessage(e))
      data.frame(Status = "FAILED", Message = conditionMessage(e))
    })
  }
  tdrx_write_csv(gnn_status, file.path(OUT_DIR, "GNN_EXTERNAL_MODULE_STATUS.csv"))
}

# ==========================================================
# 12. EXPORT ALL GENERATED RASTER FIGURES TO TIFF
# ==========================================================
# Original PNG/PDF files are retained. TIFF conversion preserves original
# pixel dimensions; assigning 300 dpi does not invent image detail.
# The new external ML figures above are created as TIFF directly.

tdrx_convert_figure_tiff <- function(source, target) {
  if (requireNamespace("magick", quietly = TRUE)) {
    im <- magick::image_read(source)
    magick::image_write(im, path = target, format = "tiff",
                        compression = "lzw", density = "300x300")
  } else if (grepl("\\.png$", source, ignore.case = TRUE) &&
             requireNamespace("png", quietly = TRUE)) {
    im <- png::readPNG(source)
    h <- dim(im)[1]; w <- dim(im)[2]
    grDevices::tiff(target, width = w, height = h, units = "px",
                    res = 300, compression = "lzw", bg = "white")
    tryCatch({
      grid::grid.newpage()
      grid::grid.raster(im, width = grid::unit(1, "npc"),
                        height = grid::unit(1, "npc"), interpolate = FALSE)
    }, finally = grDevices::dev.off())
  } else if (grepl("\\.jpe?g$", source, ignore.case = TRUE) &&
             requireNamespace("jpeg", quietly = TRUE)) {
    im <- jpeg::readJPEG(source)
    h <- dim(im)[1]; w <- dim(im)[2]
    grDevices::tiff(target, width = w, height = h, units = "px",
                    res = 300, compression = "lzw", bg = "white")
    tryCatch({
      grid::grid.newpage()
      grid::grid.raster(im, width = grid::unit(1, "npc"),
                        height = grid::unit(1, "npc"), interpolate = FALSE)
    }, finally = grDevices::dev.off())
  } else stop("No TIFF decoder: install.packages('png') or install.packages('magick')")
  if (!file.exists(target) || file.info(target)$size < 100L) {
    stop("TIFF output was not created or is empty")
  }
  invisible(target)
}

tdrx_export_all_figures_tiff <- function(root) {
  figures <- list.files(root, pattern = "\\.(png|jpg|jpeg)$",
                        full.names = TRUE, recursive = TRUE, ignore.case = TRUE)
  records <- lapply(figures, function(src) {
    dst <- sub("\\.(png|jpg|jpeg)$", ".tiff", src, ignore.case = TRUE)
    if (file.exists(dst) && file.info(dst)$mtime >= file.info(src)$mtime) {
      return(data.frame(Source = src, TIFF = dst, Status = "EXISTS",
                        Note = "TIFF at least as recent as raster source"))
    }
    tryCatch({
      tdrx_convert_figure_tiff(src, dst)
      data.frame(Source = src, TIFF = dst, Status = "EXPORTED",
                 Note = "300 dpi metadata, LZW, original pixel dimensions")
    }, error = function(e) {
      data.frame(Source = src, TIFF = dst, Status = "FAILED",
                 Note = conditionMessage(e))
    })
  })
  # Report PDF-only plots lacking a raster/TIFF counterpart; never silently
  # imply that a PDF has been exported if no suitable source exists.
  pdfs <- list.files(root, pattern = "\\.pdf$", full.names = TRUE,
                     recursive = TRUE, ignore.case = TRUE)
  for (src in pdfs) {
    stem <- sub("\\.pdf$", "", src, ignore.case = TRUE)
    if (!file.exists(paste0(stem, ".tiff")) &&
        !file.exists(paste0(stem, ".png"))) {
      records[[length(records) + 1L]] <- data.frame(
        Source = src, TIFF = paste0(stem, ".tiff"),
        Status = "PDF_ONLY_NEEDS_RENDERING",
        Note = "No PNG counterpart. Export PDF as TIFF manually or install a PDF rasterizer")
    }
  }
  if (length(records)) {
    out <- do.call(rbind, records)
  } else {
    out <- data.frame(Source = character(), TIFF = character(),
                      Status = character(), Note = character())
  }
  tdrx_write_csv(out, file.path(SCRIPT_DIR, "TIFF_EXPORT_STATUS.csv"))
  cat("[TIFF] Existing/exported: ",
      sum(out$Status %in% c("EXPORTED", "EXISTS")),
      " | failed: ", sum(out$Status == "FAILED"),
      " | PDF-only: ", sum(out$Status == "PDF_ONLY_NEEDS_RENDERING"), "\n", sep = "")
  if (any(out$Status %in% c("FAILED", "PDF_ONLY_NEEDS_RENDERING"))) {
    warning("Some figures have no TIFF counterpart; inspect TIFF_EXPORT_STATUS.csv")
  }
  invisible(out)
}

if (isTRUE(RUN_TIFF_EXPORT)) {
  cat("\n=== Export all pipeline figures as TIFF ===\n")
  tdrx_export_all_figures_tiff(OUT_DIR)
}

cat("\n=== TDR FINAL + external validation completed ===\n")
cat("113-ML top-gene external results: ", TDRX_ML_EXTERNAL_DIR, "\n", sep = "")
cat("TIFF manifest: ", file.path(SCRIPT_DIR, "TIFF_EXPORT_STATUS.csv"), "\n", sep = "")
