################################################################################
# TriDiseaseRank-X | Independent GNN EXTERNAL EVIDENCE evaluation
# ADD-ON ONLY: the supplied GNN training algorithm and all other original
# scientific scripts are unchanged.
#
# This module does TWO complementary things:
#  (1) Applies each SAVED / FROZEN TD-CCHI encoder and scaler to held-out
#      cohorts, without any retraining, to assess network and embedding
#      transportability (edge Spearman correlation, gene embedding cosine,
#      adjusted Rand index of centroid assignments).
#  (2) Evaluates the external DEG evidence for GNN-ranked candidate genes
#      with an independent limma-voom analysis, using no model tuning.
#
# These are external network/biomarker-evidence checks. They are NOT clinical
# diagnostic validation and NOT external validation of 113 classifiers.
################################################################################

options(stringsAsFactors = FALSE, scipen = 999)

get_validation_dir <- function() {
  arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
  if (length(arg)) return(dirname(normalizePath(sub("^--file=", "", arg[1]), mustWork = TRUE)))
  frames <- sys.frames()
  paths <- vapply(frames, function(e) {
    if (is.null(e$ofile)) NA_character_ else as.character(e$ofile)[1]
  }, character(1))
  paths <- paths[!is.na(paths) & nzchar(paths) & file.exists(paths)]
  if (length(paths)) return(dirname(normalizePath(tail(paths, 1), mustWork = TRUE)))
  getwd()
}

ROOT <- get_validation_dir()
DATA <- Sys.getenv("TDRX_DATA_DIR", unset = file.path(ROOT, "Data"))
DISC <- file.path(ROOT, "TriDiseaseRank_results")
GNN_DIR <- file.path(DISC, "Phase4_TD_CCHI_GNN")
OUT <- file.path(DISC, "Phase8_GNN_External_Evidence")
dir.create(OUT, recursive = TRUE, showWarnings = FALSE)

packages <- c("torch", "edgeR", "limma", "data.table", "ggplot2")
missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing)) stop("Install missing packages: ", paste(missing, collapse = ", "))
source(file.path(ROOT, "TD_CCHI_GNN_R.R"))

config <- list(
  D1 = list(discovery = "GSE172381", external = "GSE203507",
            manifest = "GSE203507_verified_group_manifest.csv",
            compartment = "placenta, villous tissue"),
  D2 = list(discovery = "GSE120852", external = "GSE208592",
            manifest = "GSE208592_verified_lung_manifest.csv", compartment = NA_character_),
  D3 = list(discovery = "GSE161349", external = "GSE100243",
            manifest = NA_character_, compartment = NA_character_)
)

need_file <- function(path) {
  if (!file.exists(path)) stop("Required file missing: ", path)
  path
}

read_external_meta <- function(cfg) {
  p <- need_file(file.path(DATA, paste0(cfg$external, "_metadata.csv")))
  md <- utils::read.csv(p, stringsAsFactors = FALSE, check.names = FALSE)
  if (!all(c("Samples", "Condition") %in% names(md))) stop("Samples/Condition missing: ", p)
  if (!is.na(cfg$manifest)) {
    mf <- utils::read.csv(need_file(file.path(DATA, cfg$manifest)), stringsAsFactors = FALSE)
    if (!all(c("Samples", "Condition", "Clinical_Group", "Tissue") %in% names(mf))) {
      stop("Required manifest columns absent")
    }
    ix <- match(md$Samples, mf$Samples)
    if (anyNA(ix) || nrow(md) != nrow(mf) ||
        any(md$Condition != mf$Condition[ix])) stop("Manifest conflicts with supplied labels")
    md <- mf[ix, , drop = FALSE]
    if (!is.na(cfg$compartment)) {
      md <- md[md$Tissue == cfg$compartment, , drop = FALSE]
    }
  }
  if (anyDuplicated(md$Samples) || !all(md$Condition %in% c("Control", "Case"))) {
    stop("Invalid sample identifiers or case/control labels")
  }
  if (!all(c("Case", "Control") %in% md$Condition)) stop("Both classes are required")
  md
}

# Counts are summed over repeated symbols; TMM normalized and logCPM computed
# across the FULL gene expression universe, not only the shortlisted hubs.
read_external_expression <- function(gse, md) {
  p <- need_file(file.path(DATA, paste0(gse, "_counts_data.csv")))
  tab <- data.table::fread(p, check.names = FALSE, data.table = FALSE, showProgress = FALSE)
  if (!"gene_symbol" %in% names(tab)) stop("gene_symbol column absent in ", gse)
  if (!all(md$Samples %in% names(tab))) stop("Metadata samples missing from count matrix")
  symbols <- toupper(trimws(as.character(tab$gene_symbol)))
  symbols <- sub("[[:space:]]*(///|//|;|\\|).*$", "", symbols)
  valid <- !is.na(symbols) & nzchar(symbols) & !symbols %in% c("NA", "N/A", "NULL", "---")
  raw <- as.matrix(tab[valid, md$Samples, drop = FALSE])
  suppressWarnings(storage.mode(raw) <- "double")
  if (any(!is.finite(raw)) || any(raw < 0) || any(abs(raw - round(raw)) > 1e-6)) {
    stop(gse, ": expected finite nonnegative INTEGER raw counts")
  }
  collapsed <- rowsum(raw, group = symbols[valid], reorder = TRUE)
  collapsed <- collapsed[rowSums(collapsed) > 0, , drop = FALSE]
  if (nrow(collapsed) < 100L) stop("Too few genes after count-table filtering")
  dge <- edgeR::DGEList(counts = collapsed)
  dge <- edgeR::calcNormFactors(dge, method = "TMM")
  expr <- edgeR::cpm(dge, log = TRUE, prior.count = 2)
  list(counts = collapsed, expr = expr, metadata = md)
}

external_limma <- function(dat) {
  md <- dat$metadata
  md$Condition <- factor(md$Condition, levels = c("Control", "Case"))
  design <- stats::model.matrix(~ Condition, data = md)
  dge <- edgeR::DGEList(counts = dat$counts)
  keep <- edgeR::filterByExpr(dge, group = md$Condition)
  if (sum(keep) < 100L) stop("Insufficient genes retained for limma-voom")
  dge <- edgeR::calcNormFactors(dge[keep, , keep.lib.sizes = FALSE], method = "TMM")
  v <- limma::voom(dge, design, plot = FALSE)
  fit <- limma::eBayes(limma::lmFit(v, design))
  tab <- limma::topTable(fit, coef = "ConditionCase", number = Inf,
                         adjust.method = "BH", sort.by = "none")
  data.frame(Gene = toupper(rownames(tab)), External_LogFC = tab$logFC,
             External_P = tab$P.Value, External_FDR = tab$adj.P.Val,
             stringsAsFactors = FALSE)
}

adjusted_rand <- function(a, b) {
  if (length(a) != length(b) || length(a) < 3L) return(NA_real_)
  tab <- table(as.character(a), as.character(b))
  choose2 <- function(z) z * (z - 1) / 2
  a2 <- sum(choose2(rowSums(tab)))
  b2 <- sum(choose2(colSums(tab)))
  ab <- sum(choose2(tab))
  n2 <- choose2(length(a))
  if (n2 == 0) return(NA_real_)
  expected <- a2 * b2 / n2
  denom <- 0.5 * (a2 + b2) - expected
  if (abs(denom) < 1e-12) return(NA_real_)
  (ab - expected) / denom
}

safe_spearman <- function(x, y) {
  good <- is.finite(x) & is.finite(y)
  if (sum(good) < 3L || length(unique(x[good])) < 2L ||
      length(unique(y[good])) < 2L) return(NA_real_)
  suppressWarnings(stats::cor(x[good], y[good], method = "spearman"))
}

# True frozen-encoder inference: load saved model + original gene-order scaler;
# no gradient, retraining, recalibration, or label access in this step.
validate_frozen_pair <- function(d, pair, expr) {
  folder <- file.path(GNN_DIR, pair)
  prep <- readRDS(need_file(file.path(folder, "TD_CCHI_preprocessing_R.rds")))
  genes <- toupper(as.character(prep$genes))
  if (anyDuplicated(genes)) stop("Duplicated frozen genes in ", pair)
  missing_genes <- setdiff(genes, rownames(expr))
  if (length(missing_genes)) stop("Frozen genes absent from external cohort: ",
                                  paste(missing_genes, collapse = ", "))
  ex <- expr[genes, , drop = FALSE]
  f <- build_td_features(ex)
  scaler <- list(center = prep$center, scale = prep$scale)
  z <- apply_td_scaler(f$features, scaler)
  device <- torch::torch_device("cpu")
  x <- torch::torch_tensor(z, dtype = torch::torch_float(), device = device)
  r <- torch::torch_tensor(abs(f$corr), dtype = torch::torch_float(), device = device)
  model_path <- need_file(file.path(folder, "TD_CCHI_locked_model_R.pt"))
  model <- tryCatch(torch::torch_load(model_path, device = device),
                    error = function(e) torch::torch_load(model_path))
  model$to(device = device)
  model$eval()
  pred <- torch::with_no_grad({ model$encode(x, r) })
  h <- as.matrix(torch::as_array(pred$h$detach()$cpu()))
  A <- as.matrix(torch::as_array(pred$adaptive$detach()$cpu()))
  if (nrow(h) != length(genes) || nrow(A) != length(genes)) stop("Frozen model shape mismatch")

  orig_h_file <- need_file(file.path(folder, paste0(d, "_gene_embeddings.csv")))
  orig_A_file <- need_file(file.path(folder, paste0(d, "_adaptive_adjacency.csv")))
  orig_h <- as.matrix(utils::read.csv(orig_h_file, row.names = 1, check.names = FALSE))
  orig_A <- as.matrix(utils::read.csv(orig_A_file, row.names = 1, check.names = FALSE))
  suppressWarnings(storage.mode(orig_h) <- "double")
  suppressWarnings(storage.mode(orig_A) <- "double")
  if (!identical(dim(orig_h), dim(h)) || !identical(dim(orig_A), dim(A))) {
    stop("Discovery embedding/adjacency dimensions mismatch frozen gene list")
  }
  cosine <- rowSums(orig_h * h) /
    pmax(1e-12, sqrt(rowSums(orig_h^2)) * sqrt(rowSums(h^2)))
  ut <- upper.tri(A, diag = FALSE)
  edge_rho <- safe_spearman(orig_A[ut], A[ut])

  orig_clusters <- utils::read.csv(
    need_file(file.path(folder, "TD_CCHI_multi_resolution_clusters.csv")),
    stringsAsFactors = FALSE
  )
  ext_clusters <- cluster_assignments_td(model, pred$h, prep$k_values)
  ari <- vapply(seq_along(prep$k_values), function(i) {
    k <- as.integer(prep$k_values[i])
    original <- orig_clusters[orig_clusters$Cohort == d & orig_clusters$K == k, , drop = FALSE]
    ix <- match(genes, toupper(original$Gene))
    if (anyNA(ix)) return(NA_real_)
    ext <- as.integer(ext_clusters[[i]])
    adjusted_rand(original$Cluster[ix], ext)
  }, numeric(1))

  per_gene <- data.frame(Dataset = d, Pair = pair, Gene = genes,
                         Frozen_Embedding_Cosine = cosine, stringsAsFactors = FALSE)
  summary <- data.frame(Dataset = d, Pair = pair,
                        Frozen_Genes = length(genes),
                        Edge_Spearman = edge_rho,
                        Mean_Gene_Embedding_Cosine = mean(cosine, na.rm = TRUE),
                        Mean_Cluster_ARI = if (any(is.finite(ari))) mean(ari, na.rm = TRUE) else NA_real_,
                        stringsAsFactors = FALSE)
  ari_table <- data.frame(Dataset = d, Pair = pair, K = prep$k_values, ARI = ari)
  list(per_gene = per_gene, summary = summary, ari = ari_table)
}

run_dataset <- function(d, cfg, gnn) {
  cat("[GNN EXTERNAL] ", d, ": ", cfg$discovery, " -> ", cfg$external, "\n", sep = "")
  folder <- file.path(OUT, d)
  dir.create(folder, recursive = TRUE, showWarnings = FALSE)
  md <- read_external_meta(cfg)
  ext <- read_external_expression(cfg$external, md)
  de <- external_limma(ext)
  utils::write.csv(de, file.path(folder, "external_genomewide_limma_voom.csv"), row.names = FALSE)

  discovery_de <- utils::read.csv(need_file(file.path(
    DISC, paste0("Phase1_DEG_", d), "DEG_all.csv")), stringsAsFactors = FALSE)
  if (!all(c("gene_symbol", "logFC") %in% names(discovery_de))) {
    stop("Discovery DEG file lacks gene_symbol/logFC")
  }
  discovery_de$Gene <- toupper(trimws(discovery_de$gene_symbol))
  discovery_de <- discovery_de[!duplicated(discovery_de$Gene), c("Gene", "logFC")]
  names(discovery_de)[2] <- "Discovery_LogFC"
  genes <- merge(gnn, discovery_de, by = "Gene", all.x = TRUE, sort = FALSE)
  genes <- merge(genes, de, by = "Gene", all.x = TRUE, sort = FALSE)
  genes$GNN_Rank <- rank(-genes$S_GNN, ties.method = "min")
  genes$External_Detected <- !is.na(genes$External_LogFC)
  genes$Direction_Concordant <- ifelse(
    is.finite(genes$Discovery_LogFC) & is.finite(genes$External_LogFC),
    sign(genes$Discovery_LogFC) == sign(genes$External_LogFC), NA)
  genes$External_FDR_lt_0_05 <- ifelse(is.finite(genes$External_FDR),
                                       genes$External_FDR < 0.05, NA)
  genes <- genes[order(genes$GNN_Rank), ]
  utils::write.csv(genes, file.path(folder, "GNN_ranked_genes_external_DEG_evidence.csv"), row.names = FALSE)

  pairs <- c("D1_vs_D2", "D1_vs_D3", "D2_vs_D3")
  pairs <- pairs[grepl(d, pairs, fixed = TRUE)]
  pair_results <- lapply(pairs, function(p) {
    tryCatch(validate_frozen_pair(d, p, ext$expr), error = function(e) {
      warning(d, " ", p, " frozen inference failed: ", conditionMessage(e))
      list(error = conditionMessage(e), pair = p)
    })
  })
  good <- pair_results[!vapply(pair_results, function(x) !is.null(x$error), logical(1))]
  bad <- pair_results[vapply(pair_results, function(x) !is.null(x$error), logical(1))]
  if (length(good)) {
    per_gene <- do.call(rbind, lapply(good, `[[`, "per_gene"))
    pair_summaries <- do.call(rbind, lapply(good, `[[`, "summary"))
    cluster_ari <- do.call(rbind, lapply(good, `[[`, "ari"))
    utils::write.csv(per_gene, file.path(folder, "frozen_encoder_gene_cosine.csv"), row.names = FALSE)
    utils::write.csv(pair_summaries, file.path(folder, "frozen_encoder_pairwise_summary.csv"), row.names = FALSE)
    utils::write.csv(cluster_ari, file.path(folder, "frozen_encoder_cluster_ARI.csv"), row.names = FALSE)
    cos_summary <- aggregate(Frozen_Embedding_Cosine ~ Gene, data = per_gene, FUN = mean)
    names(cos_summary)[2] <- "Mean_Frozen_Embedding_Cosine"
    genes <- merge(genes, cos_summary, by = "Gene", all.x = TRUE, sort = FALSE)
    genes <- genes[order(genes$GNN_Rank), ]
    utils::write.csv(genes, file.path(folder, "GNN_ranked_genes_external_DEG_and_encoder.csv"), row.names = FALSE)
  }

  p1 <- ggplot2::ggplot(utils::head(genes, 20L),
                        ggplot2::aes(x = stats::reorder(Gene, S_GNN), y = External_LogFC)) +
    ggplot2::geom_col(fill = "#356C85", na.rm = TRUE) +
    ggplot2::coord_flip() + ggplot2::theme_bw(base_size = 11) +
    ggplot2::labs(x = "GNN-ranked gene", y = "External log2 fold change",
                  title = paste(cfg$external, "external expression support"))
  ggplot2::ggsave(file.path(folder, "GNN_external_gene_effects.tiff"), p1,
                  device = "tiff", width = 7.8, height = 6.2, dpi = 300,
                  compression = "lzw")

  if (length(good)) {
    pdat <- do.call(rbind, lapply(good, `[[`, "per_gene"))
    p2 <- ggplot2::ggplot(pdat, ggplot2::aes(x = Gene, y = Frozen_Embedding_Cosine,
                                             fill = Pair)) +
      ggplot2::geom_col(position = "dodge", na.rm = TRUE) +
      ggplot2::coord_flip() + ggplot2::theme_bw(base_size = 11) +
      ggplot2::labs(x = "Gene", y = "Frozen discovery vs external embedding cosine",
                    title = paste(cfg$external, "GNN frozen-encoder transport"))
    ggplot2::ggsave(file.path(folder, "GNN_frozen_encoder_embedding_cosine.tiff"), p2,
                    device = "tiff", width = 8.5, height = 6.5, dpi = 300,
                    compression = "lzw")
  }

  present <- genes[genes$External_Detected, , drop = FALSE]
  data.frame(
    Dataset = d, Discovery = cfg$discovery, External = cfg$external,
    External_Samples = nrow(md), External_Cases = sum(md$Condition == "Case"),
    External_Controls = sum(md$Condition == "Control"),
    GNN_Candidates = nrow(genes), Detected_External = nrow(present),
    Direction_Concordance = if (any(!is.na(present$Direction_Concordant)))
      mean(present$Direction_Concordant, na.rm = TRUE) else NA_real_,
    External_FDR_Significant = sum(present$External_FDR_lt_0_05, na.rm = TRUE),
    Frozen_Pairs_Completed = length(good), Frozen_Pairs_Failed = length(bad),
    Status = if (length(bad)) "PARTIAL" else "COMPLETED",
    Message = if (length(bad)) paste(vapply(bad, function(x) paste0(x$pair, ": ", x$error), character(1)), collapse = " | ") else "",
    stringsAsFactors = FALSE
  )
}

gnn_path <- need_file(file.path(GNN_DIR, "TD_CCHI_aggregate.csv"))
gnn <- utils::read.csv(gnn_path, stringsAsFactors = FALSE)
if (!all(c("Gene", "S_GNN") %in% names(gnn))) stop("GNN aggregate lacks Gene and S_GNN")
gnn$Gene <- toupper(trimws(gnn$Gene))
gnn <- gnn[!duplicated(gnn$Gene), c("Gene", "S_GNN")]

statuses <- lapply(names(config), function(d) {
  tryCatch(run_dataset(d, config[[d]], gnn), error = function(e) {
    warning(d, " external GNN validation failed: ", conditionMessage(e))
    data.frame(Dataset = d, Discovery = config[[d]]$discovery,
               External = config[[d]]$external,
               External_Samples = NA_integer_, External_Cases = NA_integer_,
               External_Controls = NA_integer_, GNN_Candidates = nrow(gnn),
               Detected_External = NA_integer_, Direction_Concordance = NA_real_,
               External_FDR_Significant = NA_integer_, Frozen_Pairs_Completed = 0L,
               Frozen_Pairs_Failed = NA_integer_, Status = "FAILED",
               Message = conditionMessage(e), stringsAsFactors = FALSE)
  })
})
status <- do.call(rbind, statuses)
utils::write.csv(status, file.path(OUT, "GNN_VALIDATION_STATUS.csv"), row.names = FALSE)
writeLines(c(
  "TriDiseaseRank-X independent GNN evidence evaluation",
  "Frozen TD-CCHI weights and training scalers are loaded; NO external retraining.",
  "External RNA-seq counts are TMM-normalized, then converted to logCPM.",
  "Embedding cosine, edge Spearman, and cluster ARI assess network transportability.",
  "External limma-voom supports gene-level expression replication only.",
  "Different tissues/phenotypes across all discovery/external pairings; NOT diagnostic validation.",
  "GSE203507 uses villous samples only; FGR-only cases remain in the supplied composite label.",
  "GSE208592 PAH lung is not systemic hypertension and differs from ventricular failure discovery.",
  "GSE161349 CRC cell genotype groups differ from GSE100243 tumor vs normal tissue.",
  "No subject IDs for paired samples were available in the supplied two-column metadata.",
  "A positive cosine or correlation does not establish clinical prediction performance."
), file.path(OUT, "INTERPRETATION_AND_LIMITATIONS.txt"))
cat("[GNN EXTERNAL] Completed. Results: ", OUT, "\n", sep = "")
print(status[, c("Dataset", "Status", "Frozen_Pairs_Completed", "Frozen_Pairs_Failed")], row.names = FALSE)
